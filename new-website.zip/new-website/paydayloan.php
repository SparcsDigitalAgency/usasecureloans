<!-- header -->
<?php 

   $meta_tags=array(
         'title'        => 'USA Secure Loans ',
      'description'  => '',
      'keywords'=>'',
      "no-index" => true,
      'no-follow' =>true,
      'no-archieve' =>true,

   );

include_once('partials/header.php')

?>
        
        <section class="form_page">
            <div class="container">
                <div class="row">
                   <div class="col-lg-12">
                    <div class="form-title text-center">
                        <h1>Get A Loan Now Quickly And Easily</h1>
                        <h2>Apply Now in 2 Easy Steps!</h2>
                    </div>
                    
                       <script language="javascript">
window.lmpost = {};
window.lmpost.options = {campaignid: '220015', subid:'', testresult: '', domain: 'https://www.paydaylendersearch.com/forms/paydayv3/', form: '../2page_form_label_v2', leadtypeid: '9'};
document.write('<script id="leadsb2cformsrc" async="async" type="text/javascript" src="' + lmpost.options.domain + 'Scripts/forms.core.js"><\/script>');
</script>
                   </div> 
                </div>
            </div>
        </section>


<?php include_once('partials/footer.php')?>